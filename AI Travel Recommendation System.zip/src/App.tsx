import React, { useState } from 'react';
import { Compass, Thermometer, Wallet } from 'lucide-react';
import { destinations } from './data/destinations';
import { getRecommendations } from './utils/recommendationEngine';
import { UserPreferences, RecommendationScore } from './types';

const interests = [
  'beach', 'culture', 'food', 'history', 'adventure',
  'relaxation', 'shopping', 'nature', 'nightlife'
];

function App() {
  const [preferences, setPreferences] = useState<UserPreferences>({
    climate: 'tropical',
    budget: 'moderate',
    interests: []
  });
  
  const [recommendations, setRecommendations] = useState<RecommendationScore[]>([]);
  const [showResults, setShowResults] = useState(false);

  const handleGetRecommendations = () => {
    const results = getRecommendations(destinations, preferences);
    setRecommendations(results);
    setShowResults(true);
  };

  const handleInterestToggle = (interest: string) => {
    setPreferences(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-indigo-900 mb-4">
            <Compass className="inline-block mr-2 mb-1" />
            AI Travel Recommendations
          </h1>
          <p className="text-gray-600">Discover your perfect destination</p>
        </div>

        {!showResults ? (
          <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg p-8">
            <div className="mb-8">
              <label className="block text-gray-700 text-lg font-semibold mb-4">
                <Thermometer className="inline-block mr-2 mb-1" />
                Preferred Climate
              </label>
              <select
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                value={preferences.climate}
                onChange={(e) => setPreferences(prev => ({ ...prev, climate: e.target.value }))}
              >
                <option value="tropical">Tropical</option>
                <option value="temperate">Temperate</option>
                <option value="cold">Cold</option>
              </select>
            </div>

            <div className="mb-8">
              <label className="block text-gray-700 text-lg font-semibold mb-4">
                <Wallet className="inline-block mr-2 mb-1" />
                Budget Range
              </label>
              <select
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                value={preferences.budget}
                onChange={(e) => setPreferences(prev => ({ ...prev, budget: e.target.value }))}
              >
                <option value="budget">Budget</option>
                <option value="moderate">Moderate</option>
                <option value="luxury">Luxury</option>
              </select>
            </div>

            <div className="mb-8">
              <label className="block text-gray-700 text-lg font-semibold mb-4">
                Interests (Select multiple)
              </label>
              <div className="grid grid-cols-3 gap-3">
                {interests.map(interest => (
                  <button
                    key={interest}
                    onClick={() => handleInterestToggle(interest)}
                    className={`p-2 rounded-lg text-sm font-medium transition-colors
                      ${preferences.interests.includes(interest)
                        ? 'bg-indigo-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                  >
                    {interest.charAt(0).toUpperCase() + interest.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGetRecommendations}
              disabled={preferences.interests.length === 0}
              className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold
                hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
            >
              Get Recommendations
            </button>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setShowResults(false)}
              className="mb-6 text-indigo-600 font-medium hover:text-indigo-800"
            >
              ← Back to Preferences
            </button>
            
            <div className="grid gap-6">
              {recommendations.map(({ destination, score }) => (
                <div
                  key={destination.id}
                  className="bg-white rounded-xl shadow-lg overflow-hidden flex"
                >
                  <div className="w-1/3">
                    <img
                      src={destination.image}
                      alt={destination.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="w-2/3 p-6">
                    <div className="flex justify-between items-start mb-4">
                      <h2 className="text-2xl font-bold text-gray-900">
                        {destination.name}
                      </h2>
                      <div className="bg-indigo-100 text-indigo-800 px-3 py-1 rounded-full">
                        Match: {Math.round(score * 100)}%
                      </div>
                    </div>
                    <p className="text-gray-600 mb-4">{destination.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {destination.activities.map(activity => (
                        <span
                          key={activity}
                          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                        >
                          {activity}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;