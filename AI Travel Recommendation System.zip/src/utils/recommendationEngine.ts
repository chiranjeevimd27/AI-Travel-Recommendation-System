import { Destination, UserPreferences, RecommendationScore } from '../types';

export function getRecommendations(
  destinations: Destination[],
  preferences: UserPreferences
): RecommendationScore[] {
  return destinations
    .map(destination => ({
      destination,
      score: calculateScore(destination, preferences)
    }))
    .sort((a, b) => b.score - a.score);
}

function calculateScore(destination: Destination, preferences: UserPreferences): number {
  let score = 0;
  
  // Climate match
  if (destination.climate === preferences.climate) {
    score += 0.4;
  }
  
  // Budget match
  if (destination.budget === preferences.budget) {
    score += 0.3;
  }
  
  // Activities/interests match
  const interestMatch = destination.activities.filter(
    activity => preferences.interests.includes(activity)
  ).length;
  score += (interestMatch / destination.activities.length) * 0.3;
  
  // Add base rating influence
  score = score * 0.8 + (destination.rating / 5) * 0.2;
  
  return Number(score.toFixed(2));
}