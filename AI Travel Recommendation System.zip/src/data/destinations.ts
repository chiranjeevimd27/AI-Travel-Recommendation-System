import { Destination } from '../types';

export const destinations: Destination[] = [
  {
    id: '1',
    name: 'Bali, Indonesia',
    description: 'Tropical paradise with rich culture, beaches, and temples',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4',
    climate: 'tropical',
    budget: 'moderate',
    activities: ['beach', 'culture', 'temples', 'surfing'],
    rating: 4.8
  },
  {
    id: '2',
    name: 'Swiss Alps',
    description: 'Majestic mountains and world-class skiing',
    image: 'https://images.unsplash.com/photo-1531310197839-ccf54634509e',
    climate: 'cold',
    budget: 'luxury',
    activities: ['skiing', 'hiking', 'scenery', 'adventure'],
    rating: 4.9
  },
  {
    id: '3',
    name: 'Prague, Czech Republic',
    description: 'Historic city with stunning architecture and rich history',
    image: 'https://images.unsplash.com/photo-1519677100203-a0e668c92439',
    climate: 'temperate',
    budget: 'budget',
    activities: ['history', 'architecture', 'food', 'culture'],
    rating: 4.7
  },
  {
    id: '4',
    name: 'Maldives',
    description: 'Luxury island paradise with crystal clear waters',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8',
    climate: 'tropical',
    budget: 'luxury',
    activities: ['beach', 'snorkeling', 'relaxation', 'water-sports'],
    rating: 4.9
  },
  {
    id: '5',
    name: 'Tokyo, Japan',
    description: 'Ultra-modern city with traditional charm',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf',
    climate: 'temperate',
    budget: 'moderate',
    activities: ['technology', 'culture', 'food', 'shopping'],
    rating: 4.8
  }
];