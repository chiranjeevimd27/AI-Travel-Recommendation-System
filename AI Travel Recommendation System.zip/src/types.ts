export interface Destination {
  id: string;
  name: string;
  description: string;
  image: string;
  climate: 'tropical' | 'temperate' | 'cold';
  budget: 'budget' | 'moderate' | 'luxury';
  activities: string[];
  rating: number;
}

export interface UserPreferences {
  climate: string;
  budget: string;
  interests: string[];
}

export interface RecommendationScore {
  destination: Destination;
  score: number;
}